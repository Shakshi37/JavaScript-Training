const x=[
    {
        "Emp_code": "SCIKEY01",
        "Name": "Hardik",
        "Designation": "PM",
        "Business_unit": "Scikey",
        "Branch": "Surat",
        "DOB": "28-09-1997",
        "Department": "PMS",
        "DOJ": "22-02-2002",
        "Email": "hardik@gmail.com",
        "Mob_no": "9977886601",
        "Gender": "MALE",
        "Experience": 3,
        "salary": 50000,
        "hobbies": [
            "cricket",
            "volleyball"
        ]
    },
    {
        "Emp_code": "SCIKEY02",
        "Name": "Vidhi",
        "Designation": "AD",
        "Business_unit": "Scikey",
        "Branch": "Surat",
        "DOB": "05-05-2000",
        "Department": "AMS",
        "DOJ": "04-09-2002",
        "Email": "vidhi@gmail.com",
        "Mob_no": "8237767340",
        "Gender": "FEMALE",
        "Experience": 2,
        "salary": 30000,
        "hobbies": [
            "hockey",
            "volleyball"
        ]
    },
    {
        "Emp_code": "SCIKEY04",
        "Name": "Pratik",
        "Designation": "DEV",
        "Business_unit": "Scikey",
        "Branch": "Mumbai",
        "DOB": "30-10-1987",
        "Department": "GMS",
        "DOJ": "10-02-2006",
        "Email": "pratik.khan@gmail.com",
        "Mob_no": "999978801",
        "Gender": "MALE",
        "Experience": 10,
        "salary": 80000,
        "hobbies": [
            "cricket",
            "Music"
        ]
    },
    {
        "Emp_code": "SCIKEY05",
        "Name": "Komal",
        "Designation": "SDEV",
        "Business_unit": "Scikey",
        "Branch": "Surat",
        "DOB": "28-05-1990",
        "Department": "AMS",
        "DOJ": "15-03-2001",
        "Email": "komal@gmail.com",
        "Mob_no": "997788000",
        "Gender": "FEMALE",
        "Experience": 1,
        "salary": 20000,
        "hobbies": [
            "volleyball"
        ]
    },
    {
        "Emp_code": "SCIKEY06",
        "Name": "Raj",
        "Designation": "PM",
        "Business_unit": "Scikey",
        "Branch": "Mumbai",
        "DOB": "28-09-1977",
        "Department": "PMS",
        "DOJ": "10-02-2000",
        "Email": "raj@gmail.com",
        "Mob_no": "9977885555",
        "Gender": "MALE",
        "Experience": 3,
        "salary": 38000,
        "hobbies": [
            "cricket",
            "volleyball"
        ]
    },
    {
        "Emp_code": "SCIKEY07",
        "Name": "Tisha",
        "Designation": "PM",
        "Business_unit": "Scikey",
        "Branch": "Surat",
        "DOB": "22-03-1997",
        "Department": "PMS",
        "DOJ": "22-02-2002",
        "Email": "tisha@gmail.com",
        "Mob_no": "2222286601",
        "Gender": "FEMALE",
        "Experience": 3,
        "salary": 50000,
        "hobbies": [
            "cricket"
        ]
    }
]

let obj={}
let salary=[]
let final_obj={}
let bobj={}
let output=[]
let bfinal_obj={}


let cobj={}
let cfinal_obj={}
let new_obj={}
let experience=[]

let dobj={}
let cri_arr=[]
let dfinal_obj={}

x.map(sal=>{
    // console.log(sal.salary)
    if(sal.salary >=30000 && sal.salary<=40000){
        // console.log(sal.Emp_code)
        obj[sal.Emp_code]={
            "salary":sal.salary
        }
        salary.push(obj)

    }
    bobj[sal.Department]=
        [{"Emp_Code":sal.Emp_code}]
    

    if(sal.Experience>2){
        cobj[sal.Emp_code]={
                  "Experience": sal.Experience
               }
       }

       sal.hobbies.map(arr=>{
        //    console.log(arr)
        if(arr=='cricket'){
            cri_arr.push(sal.Emp_code)
            // console.log(hobb.Emp_code)
        }
        
})

})
final_obj["salary_details:"]=salary
console.log()
console.log("-------------------Answer-1---------------------------------")
console.log()
console.log(JSON.stringify(final_obj))

bfinal_obj["department_details"]=bobj
// obj[department]=emp_code
console.log()
console.log("-------------------------Answer-2---------------------------------")
console.log()
console.log(JSON.stringify(bfinal_obj))

experience.push(obj)
new_obj["experience_details"]=experience

cfinal_obj["experience_details"]=new_obj
console.log()
console.log("------------------------------Answer-3------------------------------------------------")

console.log()
console.log(JSON.stringify(cfinal_obj))
dobj["cricket"]=cri_arr
dfinal_obj["hobbies_details"]=dobj
console.log()
console.log("----------------------Answer-4-------------------------------")
console.log()
console.log(dfinal_obj)
console.log()




