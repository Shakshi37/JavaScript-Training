var a={
    "data": {
        "company_info": {
            "account_status_of_company": [
                {
                    "status_code": 1,
                    "status_name": "Active",
                    "status_key": "ACC_Active"
                },
                {
                    "status_code": 2,
                    "status_name": "In-Active",
                    "status_key": "ACC_Not_Active"
                },
                {
                    "status_code": 3,
                    "status_name": "Hold",
                    "status_key": "ACC_DO_Not_Sale"
                },
                {
                    "status_code": 4,
                    "status_name": "Block",
                    "status_key": "BLOCK"
                }
            ],
            "handling_company": [
                {
                    "company_code": 1,
                    "company_name": "SRK",
                    "company_key": "SRK"
                },
                {
                    "company_code": 2,
                    "company_name": "OD",
                    "company_key": "SG"
                },
                {
                    "company_code": 3,
                    "company_name": "1D",
                    "company_key": "RG"
                }
            ],
            "company_grade": [
                {
                    "grade_code": 1,
                    "grade_name": "EXCELLENT"
                },
                {
                    "grade_code": 2,
                    "grade_name": "VERY GOOD"
                },
                {
                    "grade_code": 3,
                    "grade_name": "GOOD"
                },
                {
                    "grade_code": 4,
                    "grade_name": "AVERAGE"
                },
                {
                    "grade_code": 5,
                    "grade_name": "POOR"
                }
            ],
            "business_type": [
                {
                    "business_type_code": 1,
                    "business_type_name": "Diamond Exporter"
                },
                {
                    "business_type_code": 2,
                    "business_type_name": "Diamond Import-Export"
                },
                {
                    "business_type_code": 3,
                    "business_type_name": "Diamond Importer"
                },
                {
                    "business_type_code": 4,
                    "business_type_name": "Diamond Mfg"
                },
                {
                    "business_type_code": 5,
                    "business_type_name": "Jewellery Mfg."
                },
                {
                    "business_type_code": 6,
                    "business_type_name": "TRADER"
                },
                {
                    "business_type_code": 7,
                    "business_type_name": "Trading & Jewellery Mfg."
                },
                {
                    "business_type_code": 8,
                    "business_type_name": "Mega Chain"
                },
                {
                    "business_type_code": 9,
                    "business_type_name": "Chain"
                },
                {
                    "business_type_code": 10,
                    "business_type_name": "Luxury Brand"
                },
                {
                    "business_type_code": 11,
                    "business_type_name": "Independent Jewellers"
                },
                {
                    "business_type_code": 12,
                    "business_type_name": "Third Party Online"
                },
                {
                    "business_type_code": 13,
                    "business_type_name": "Wholesaler Online"
                },
                {
                    "business_type_code": 14,
                    "business_type_name": "Wholesaler Offline"
                }
            ],
            "company_group": [
                {
                    "group_code": 1,
                    "group_name": "Leads",
                    "group_key": "LEADS"
                },
                {
                    "group_code": 2,
                    "group_name": "Registered",
                    "group_key": "REGISTERED"
                },
                {
                    "group_code": 4,
                    "group_name": "Block",
                    "group_key": "BLOCK"
                },
                {
                    "group_code": 6,
                    "group_name": "Potential",
                    "group_key": "POTENTIAL"
                },
                {
                    "group_code": 7,
                    "group_name": "Non Potential",
                    "group_key": "NOT_POTENTIAL"
                },
                {
                    "group_code": 8,
                    "group_name": "Show Leads",
                    "group_key": "SHOW_LEADS"
                }
            ],
            "member_of_trade": [
                {
                    "trade_code": 1,
                    "trade_name": "Hong Kong, Gems & Jewelry Show - March"
                },
                {
                    "trade_code": 2,
                    "trade_name": "Hong Kong, Gems & Jewelry Show - June"
                },
                {
                    "trade_code": 3,
                    "trade_name": "Hong Kong, Gems & Jewelry Show - September"
                },
                {
                    "trade_code": 4,
                    "trade_name": "Hong Kong, Gems & Jewelry Show - November"
                },
                {
                    "trade_code": 5,
                    "trade_name": "Switzerland, Basel Show"
                },
                {
                    "trade_code": 6,
                    "trade_name": "USA, JCK Las Vegas Show1"
                },
                {
                    "trade_code": 7,
                    "trade_name": "Italy, Vicenza Show"
                },
                {
                    "trade_code": 8,
                    "trade_name": "YES"
                },
                {
                    "trade_code": 9,
                    "trade_name": "MUMBAI DIAMOND MERCHANT ASSOCIATION"
                },
                {
                    "trade_code": 10,
                    "trade_name": "ahmedabad diamond association"
                },
                {
                    "trade_code": 11,
                    "trade_name": "Union bank of israel ltd"
                },
                {
                    "trade_code": 12,
                    "trade_name": "GJEPC"
                },
                {
                    "trade_code": 13,
                    "trade_name": "skylinejewelryinc@gmail.com "
                },
                {
                    "trade_code": 14,
                    "trade_name": "DIAMOND DEALER CLUB"
                },
                {
                    "trade_code": 15,
                    "trade_name": "Diamond Council of America"
                },
                {
                    "trade_code": 16,
                    "trade_name": "HKTDC"
                },
                {
                    "trade_code": 17,
                    "trade_name": "Ian and Lucas"
                },
                {
                    "trade_code": 18,
                    "trade_name": "Jewelers board of trade"
                },
                {
                    "trade_code": 19,
                    "trade_name": "GIA"
                },
                {
                    "trade_code": 20,
                    "trade_name": "RAPNET"
                },
                {
                    "trade_code": 21,
                    "trade_name": "Others"
                },
                {
                    "trade_code": 22,
                    "trade_name": "TinaKhiatani-VICEPRESIDENT"
                },
                {
                    "trade_code": 23,
                    "trade_name": "DBA NER DIAMOND CORP"
                },
                {
                    "trade_code": 24,
                    "trade_name": "5048349999 EXT- 3343"
                },
                {
                    "trade_code": 25,
                    "trade_name": "Canadian Jewellers Association"
                },
                {
                    "trade_code": 26,
                    "trade_name": "parshva.jewel@yahoo.in   vishaljain37@yahoo.com"
                },
                {
                    "trade_code": 27,
                    "trade_name": "HYDERABAD TWIN CITIES JEWELLERS ASSOCIATION"
                },
                {
                    "trade_code": 28,
                    "trade_name": "Swiss-41-22-580-2822 Hong Kong"
                },
                {
                    "trade_code": 29,
                    "trade_name": "Diamond Merchan Associon"
                },
                {
                    "trade_code": 30,
                    "trade_name": "DELHI JEWELLERS ASSOCIATION"
                },
                {
                    "trade_code": 31,
                    "trade_name": "1-888-349-8299/ EXT-775"
                },
                {
                    "trade_code": 32,
                    "trade_name": "GISA 28296720"
                },
                {
                    "trade_code": 33,
                    "trade_name": "440126000493468-Business Registration number "
                },
                {
                    "trade_code": 34,
                    "trade_name": "CUSHIONS WITH 60 DEPTH-ext 103"
                },
                {
                    "trade_code": 35,
                    "trade_name": "Mdma"
                },
                {
                    "trade_code": 36,
                    "trade_name": "LDB London"
                },
                {
                    "trade_code": 37,
                    "trade_name": "making high end jewellery. She like to start diamond buying"
                },
                {
                    "trade_code": 38,
                    "trade_name": "WORLD FEDERATION DIAMOND BOURSE"
                },
                {
                    "trade_code": 39,
                    "trade_name": "Jewellery Quarter Association"
                },
                {
                    "trade_code": 40,
                    "trade_name": "Brian Hocheiser at bhocheiser@mcfina.com"
                },
                {
                    "trade_code": 41,
                    "trade_name": "dgditaly@gmail.com"
                },
                {
                    "trade_code": 42,
                    "trade_name": "THE JEWELS BOARD OF TRADES-NYDDC"
                },
                {
                    "trade_code": 43,
                    "trade_name": "Company Registration Number: 9369 (AWDC)"
                },
                {
                    "trade_code": 44,
                    "trade_name": "GJF"
                },
                {
                    "trade_code": 45,
                    "trade_name": "AGS MEMBER"
                },
                {
                    "trade_code": 46,
                    "trade_name": "Select"
                },
                {
                    "trade_code": 47,
                    "trade_name": "Business Registration number =2013/188811/07"
                },
                {
                    "trade_code": 48,
                    "trade_name": "MAZAL & BRACHA DIAMOND LTD IS SAME"
                },
                {
                    "trade_code": 49,
                    "trade_name": "Jim & Gerry Salyer &their2 sons"
                },
                {
                    "trade_code": 50,
                    "trade_name": "grandiose_jewellery@mail.ru"
                },
                {
                    "trade_code": 51,
                    "trade_name": "Bharat Diamond Bourse"
                },
                {
                    "trade_code": 52,
                    "trade_name": "GJTCI"
                },
                {
                    "trade_code": 53,
                    "trade_name": "Jewelers Board of Trade ID: 00263558"
                },
                {
                    "trade_code": 54,
                    "trade_name": "RAPNET-78938"
                }
            ],
            "offices_countries": [
                {
                    "country_code": 1,
                    "country_name": "U.S.A."
                },
                {
                    "country_code": 2,
                    "country_name": "BELGIUM"
                },
                {
                    "country_code": 3,
                    "country_name": "ISRAEL"
                },
                {
                    "country_code": 4,
                    "country_name": "HONG KONG"
                },
                {
                    "country_code": 5,
                    "country_name": "JAPAN"
                },
                {
                    "country_code": 6,
                    "country_name": "U.A.E."
                },
                {
                    "country_code": 7,
                    "country_name": "THAILAND"
                },
                {
                    "country_code": 8,
                    "country_name": "NEW ZEALAND"
                },
                {
                    "country_code": 9,
                    "country_name": "UNITED KINGDOM"
                },
                {
                    "country_code": 10,
                    "country_name": "TAIWAN"
                },
                {
                    "country_code": 11,
                    "country_name": "INDIA"
                },
                {
                    "country_code": 12,
                    "country_name": "GERMANY"
                },
                {
                    "country_code": 13,
                    "country_name": "CANADA"
                },
                {
                    "country_code": 14,
                    "country_name": "SWITZERLAND"
                },
                {
                    "country_code": 15,
                    "country_name": "MAURITIUS"
                },
                {
                    "country_code": 16,
                    "country_name": "KOREA,REPUBLIC OF"
                },
                {
                    "country_code": 17,
                    "country_name": "SOUTH AFRICA"
                },
                {
                    "country_code": 18,
                    "country_name": "SINGAPORE"
                },
                {
                    "country_code": 19,
                    "country_name": "AUSTRALIA"
                },
                {
                    "country_code": 20,
                    "country_name": "IRELAND"
                },
                {
                    "country_code": 21,
                    "country_name": "ITALY"
                },
                {
                    "country_code": 22,
                    "country_name": "MALAYSIA"
                },
                {
                    "country_code": 23,
                    "country_name": "FRANCE"
                },
                {
                    "country_code": 24,
                    "country_name": "CHINA"
                },
                {
                    "country_code": 25,
                    "country_name": "BERMUDA"
                },
                {
                    "country_code": 26,
                    "country_name": "SWEDEN"
                },
                {
                    "country_code": 27,
                    "country_name": "GREECE"
                },
                {
                    "country_code": 28,
                    "country_name": "PHILIPPINES"
                },
                {
                    "country_code": 29,
                    "country_name": "CYPRUS"
                },
                {
                    "country_code": 30,
                    "country_name": "SPAIN"
                },
                {
                    "country_code": 31,
                    "country_name": "INDONESIA"
                },
                {
                    "country_code": 32,
                    "country_name": "LEBANON"
                },
                {
                    "country_code": 33,
                    "country_name": "YEMEN, DEMOCRATIC"
                },
                {
                    "country_code": 34,
                    "country_name": "SAUDI ARABIA"
                },
                {
                    "country_code": 35,
                    "country_name": "AUSTRIA"
                },
                {
                    "country_code": 36,
                    "country_name": "CAMBODIA"
                },
                {
                    "country_code": 37,
                    "country_name": "TURKEY"
                },
                {
                    "country_code": 38,
                    "country_name": "RUSSIA"
                },
                {
                    "country_code": 39,
                    "country_name": "SRI LANKA"
                },
                {
                    "country_code": 40,
                    "country_name": "NETHERLANDS"
                },
                {
                    "country_code": 41,
                    "country_name": "NAMIBIA"
                },
                {
                    "country_code": 42,
                    "country_name": "LATVIA"
                },
                {
                    "country_code": 43,
                    "country_name": "CONGO, DEMOCRATIC REPUBLIC OF THE"
                },
                {
                    "country_code": 44,
                    "country_name": "SAINT LUCIA"
                },
                {
                    "country_code": 45,
                    "country_name": "ARMENIA"
                },
                {
                    "country_code": 46,
                    "country_name": "CZECH REPUBLIC"
                },
                {
                    "country_code": 47,
                    "country_name": "FINLAND"
                },
                {
                    "country_code": 48,
                    "country_name": "POLAND"
                },
                {
                    "country_code": 49,
                    "country_name": "SAINT PIERRE AND MIQUELON"
                },
                {
                    "country_code": 50,
                    "country_name": "ZAMBIA"
                },
                {
                    "country_code": 51,
                    "country_name": "WESTERN SAHARA"
                },
                {
                    "country_code": 52,
                    "country_name": "BRAZIL"
                },
                {
                    "country_code": 53,
                    "country_name": "BOTSWANA"
                },
                {
                    "country_code": 54,
                    "country_name": "SLOVAK REPUBLIC"
                },
                {
                    "country_code": 55,
                    "country_name": "PANAMA"
                },
                {
                    "country_code": 56,
                    "country_name": "NORWAY"
                },
                {
                    "country_code": 57,
                    "country_name": "FRENCH POLYNESIA"
                },
                {
                    "country_code": 58,
                    "country_name": "LIECHTENSTEIN"
                },
                {
                    "country_code": 59,
                    "country_name": "ALGERIA"
                },
                {
                    "country_code": 60,
                    "country_name": "COLOMBIA"
                },
                {
                    "country_code": 61,
                    "country_name": "AFGHANISTAN"
                },
                {
                    "country_code": 62,
                    "country_name": "ALBANIA"
                },
                {
                    "country_code": 63,
                    "country_name": "AMERICAN SAMOA"
                },
                {
                    "country_code": 64,
                    "country_name": "ANDORRA"
                },
                {
                    "country_code": 65,
                    "country_name": "ANGOLA"
                },
                {
                    "country_code": 66,
                    "country_name": "ANGUILLA"
                },
                {
                    "country_code": 67,
                    "country_name": "ANTARCTICA"
                },
                {
                    "country_code": 68,
                    "country_name": "ANTIGUA"
                },
                {
                    "country_code": 69,
                    "country_name": "ARGENTINA"
                },
                {
                    "country_code": 70,
                    "country_name": "ARUBA"
                },
                {
                    "country_code": 71,
                    "country_name": "AZERBAIJAN"
                },
                {
                    "country_code": 72,
                    "country_name": "BAHAMAS"
                },
                {
                    "country_code": 73,
                    "country_name": "KINGDOM OF BAHRAIN"
                },
                {
                    "country_code": 74,
                    "country_name": "BANGLADESH"
                },
                {
                    "country_code": 75,
                    "country_name": "BARBADOS"
                },
                {
                    "country_code": 76,
                    "country_name": "BELARUS"
                },
                {
                    "country_code": 77,
                    "country_name": "BELIZE"
                },
                {
                    "country_code": 78,
                    "country_name": "BENIN"
                },
                {
                    "country_code": 79,
                    "country_name": "BHUTAN"
                },
                {
                    "country_code": 80,
                    "country_name": "BOLIVIA"
                },
                {
                    "country_code": 81,
                    "country_name": "BOSNIA AND HERZEGOVINA"
                },
                {
                    "country_code": 82,
                    "country_name": "BOUVET ISLAND"
                },
                {
                    "country_code": 83,
                    "country_name": "BRITISH INDIAN OCEAN TERRITORY"
                },
                {
                    "country_code": 84,
                    "country_name": "BRITISH VIRGIN ISLANDS"
                },
                {
                    "country_code": 85,
                    "country_name": "BRUNEI"
                },
                {
                    "country_code": 86,
                    "country_name": "BULGARIA"
                },
                {
                    "country_code": 88,
                    "country_name": "BURKINA FASO"
                },
                {
                    "country_code": 90,
                    "country_name": "BURUNDI"
                },
                {
                    "country_code": 92,
                    "country_name": "CAMEROON"
                },
                {
                    "country_code": 93,
                    "country_name": "CANARY ISLANDS"
                },
                {
                    "country_code": 94,
                    "country_name": "CAPE VERDE ISLANDS"
                },
                {
                    "country_code": 95,
                    "country_name": "CAYMAN ISLANDS"
                },
                {
                    "country_code": 96,
                    "country_name": "CENTRAL AFRICAN REPUBLIC"
                },
                {
                    "country_code": 97,
                    "country_name": "CHAD"
                },
                {
                    "country_code": 98,
                    "country_name": "CHILE"
                },
                {
                    "country_code": 99,
                    "country_name": "CHRISTMAS ISLAND"
                },
                {
                    "country_code": 100,
                    "country_name": "SINT MAARTEN"
                },
                {
                    "country_code": 101,
                    "country_name": "ZIMBABWE"
                },
                {
                    "country_code": 102,
                    "country_name": "COCOS (KEELING ISLANDS)"
                },
                {
                    "country_code": 103,
                    "country_name": "COMOROS"
                },
                {
                    "country_code": 104,
                    "country_name": "CONGO"
                },
                {
                    "country_code": 106,
                    "country_name": "COOK ISLANDS"
                },
                {
                    "country_code": 107,
                    "country_name": "COSTA RICA"
                },
                {
                    "country_code": 108,
                    "country_name": "COTE D IVOIRE"
                },
                {
                    "country_code": 109,
                    "country_name": "CROATIA"
                },
                {
                    "country_code": 110,
                    "country_name": "CUBA"
                },
                {
                    "country_code": 112,
                    "country_name": "DAHOMEY"
                },
                {
                    "country_code": 113,
                    "country_name": "DENMARK"
                },
                {
                    "country_code": 114,
                    "country_name": "DJIBOUTI"
                },
                {
                    "country_code": 115,
                    "country_name": "DOMINICA"
                },
                {
                    "country_code": 116,
                    "country_name": "DOMINICAN REPUBLIC"
                },
                {
                    "country_code": 117,
                    "country_name": "EAST TIMOR"
                },
                {
                    "country_code": 118,
                    "country_name": "ECUADOR"
                },
                {
                    "country_code": 119,
                    "country_name": "EGYPT"
                },
                {
                    "country_code": 120,
                    "country_name": "EL SALVADOR"
                },
                {
                    "country_code": 121,
                    "country_name": "EQUATORIAL GUINEA"
                },
                {
                    "country_code": 122,
                    "country_name": "ERITREA"
                },
                {
                    "country_code": 123,
                    "country_name": "ESTONIA"
                },
                {
                    "country_code": 124,
                    "country_name": "ETHIOPIA"
                },
                {
                    "country_code": 125,
                    "country_name": "EUROPEAN UNION"
                },
                {
                    "country_code": 126,
                    "country_name": "FALKLAND ISLANDS"
                },
                {
                    "country_code": 127,
                    "country_name": "FAROE ISLANDS"
                },
                {
                    "country_code": 128,
                    "country_name": "FIJI"
                },
                {
                    "country_code": 129,
                    "country_name": "FRENCH GUIANA"
                },
                {
                    "country_code": 130,
                    "country_name": "FRENCH SOUTH & ANTARTIC TERR"
                },
                {
                    "country_code": 131,
                    "country_name": "FRENCH SOUTHERN TERRITORIES"
                },
                {
                    "country_code": 132,
                    "country_name": "FRENCH TERRITORY OF THE AFARS AND THE ISSAS"
                },
                {
                    "country_code": 133,
                    "country_name": "GABON"
                },
                {
                    "country_code": 134,
                    "country_name": "GAMBIA"
                },
                {
                    "country_code": 136,
                    "country_name": "GEORGIA"
                },
                {
                    "country_code": 137,
                    "country_name": "GHANA"
                },
                {
                    "country_code": 138,
                    "country_name": "GIBRALTAR"
                },
                {
                    "country_code": 139,
                    "country_name": "GILBERT & ELICE ISLANDS"
                },
                {
                    "country_code": 140,
                    "country_name": "SINT MAARTEN (DUTCH)"
                },
                {
                    "country_code": 141,
                    "country_name": "GREENLAND"
                },
                {
                    "country_code": 142,
                    "country_name": "GRENADA"
                },
                {
                    "country_code": 143,
                    "country_name": "GUADELOUPE"
                },
                {
                    "country_code": 144,
                    "country_name": "GUAM"
                },
                {
                    "country_code": 145,
                    "country_name": "GUATEMALA"
                },
                {
                    "country_code": 146,
                    "country_name": "GUERNSEY"
                },
                {
                    "country_code": 147,
                    "country_name": "GUINEA"
                },
                {
                    "country_code": 148,
                    "country_name": "GUINEA-BISSAU"
                },
                {
                    "country_code": 149,
                    "country_name": "GUYANA"
                },
                {
                    "country_code": 150,
                    "country_name": "HAITI"
                },
                {
                    "country_code": 151,
                    "country_name": "HEARD ISLAND AND MCDONALD ISLANDS"
                },
                {
                    "country_code": 152,
                    "country_name": "HONDURAS"
                },
                {
                    "country_code": 153,
                    "country_name": "HUNGARY"
                },
                {
                    "country_code": 154,
                    "country_name": "ICELAND"
                },
                {
                    "country_code": 155,
                    "country_name": "IRAN"
                },
                {
                    "country_code": 156,
                    "country_name": "IRAQ"
                },
                {
                    "country_code": 157,
                    "country_name": "ISLE OF MAN"
                },
                {
                    "country_code": 158,
                    "country_name": "SAINT-MARTIN (FRENCH)"
                },
                {
                    "country_code": 159,
                    "country_name": "JAMAICA"
                },
                {
                    "country_code": 160,
                    "country_name": "JERSEY"
                },
                {
                    "country_code": 161,
                    "country_name": "JORDAN"
                },
                {
                    "country_code": 162,
                    "country_name": "KAZAKHSTAN"
                },
                {
                    "country_code": 163,
                    "country_name": "KENYA"
                },
                {
                    "country_code": 164,
                    "country_name": "KIRIBATI"
                },
                {
                    "country_code": 165,
                    "country_name": "KOREA,DEMOCRATIC PEOPLES REPUBLIC OF"
                },
                {
                    "country_code": 167,
                    "country_name": "KOSOVO"
                },
                {
                    "country_code": 168,
                    "country_name": "KUWAIT"
                },
                {
                    "country_code": 169,
                    "country_name": "KYRGYZSTAN"
                },
                {
                    "country_code": 170,
                    "country_name": "LAO PEOPLES DEMOCRATIC REPUBLIC"
                },
                {
                    "country_code": 171,
                    "country_name": "LESOTHO"
                },
                {
                    "country_code": 172,
                    "country_name": "LIBERIA"
                },
                {
                    "country_code": 173,
                    "country_name": "LIBYAN ARAB REPUBLIC"
                },
                {
                    "country_code": 174,
                    "country_name": "LITHUANIA"
                },
                {
                    "country_code": 175,
                    "country_name": "LUXEMBOURG"
                },
                {
                    "country_code": 176,
                    "country_name": "MACAO"
                },
                {
                    "country_code": 177,
                    "country_name": "MACEDONIA,THE FORMER YUGOSLAV REPUBLIC OF"
                },
                {
                    "country_code": 178,
                    "country_name": "MADAGASCAR"
                },
                {
                    "country_code": 179,
                    "country_name": "MALAWI"
                },
                {
                    "country_code": 180,
                    "country_name": "MALDIVES"
                },
                {
                    "country_code": 181,
                    "country_name": "MALI"
                },
                {
                    "country_code": 182,
                    "country_name": "MALTA"
                },
                {
                    "country_code": 183,
                    "country_name": "MARSHALL ISLANDS"
                },
                {
                    "country_code": 184,
                    "country_name": "MARTINIQUE"
                },
                {
                    "country_code": 185,
                    "country_name": "MAURITANIA"
                },
                {
                    "country_code": 186,
                    "country_name": "MAYOTTE"
                },
                {
                    "country_code": 187,
                    "country_name": "MEXICO"
                },
                {
                    "country_code": 188,
                    "country_name": "MICRONESIA"
                },
                {
                    "country_code": 189,
                    "country_name": "MOLDOVA,REPUBLIC OF"
                },
                {
                    "country_code": 190,
                    "country_name": "MONACO"
                },
                {
                    "country_code": 191,
                    "country_name": "MONGOLIA"
                },
                {
                    "country_code": 192,
                    "country_name": "MONTENEGRO"
                },
                {
                    "country_code": 193,
                    "country_name": "MONTSERRAT"
                },
                {
                    "country_code": 194,
                    "country_name": "MOROCCO"
                },
                {
                    "country_code": 195,
                    "country_name": "MOZAMBIQUE"
                },
                {
                    "country_code": 196,
                    "country_name": "MYANMAR"
                },
                {
                    "country_code": 197,
                    "country_name": "NAURU"
                },
                {
                    "country_code": 198,
                    "country_name": "NEPAL"
                },
                {
                    "country_code": 199,
                    "country_name": "NETHERLANDS ANTILLES"
                },
                {
                    "country_code": 200,
                    "country_name": "NEW CALEDONIA"
                },
                {
                    "country_code": 201,
                    "country_name": "NICARAGUA"
                },
                {
                    "country_code": 202,
                    "country_name": "NIGER"
                },
                {
                    "country_code": 203,
                    "country_name": "NIGERIA"
                },
                {
                    "country_code": 204,
                    "country_name": "NIUE"
                },
                {
                    "country_code": 205,
                    "country_name": "NORFOLK ISLAND"
                },
                {
                    "country_code": 206,
                    "country_name": "NORTHERN MARIANA ISLANDS"
                },
                {
                    "country_code": 207,
                    "country_name": "OMAN"
                },
                {
                    "country_code": 208,
                    "country_name": "PACIFIC ISLANDS U.S. TRUST"
                },
                {
                    "country_code": 209,
                    "country_name": "PAKISTAN"
                },
                {
                    "country_code": 210,
                    "country_name": "PALAU"
                },
                {
                    "country_code": 211,
                    "country_name": "PALESTINE STATE"
                },
                {
                    "country_code": 212,
                    "country_name": "SAINT BARTHELEMY"
                },
                {
                    "country_code": 213,
                    "country_name": "PAPUA NEW GUINEA"
                },
                {
                    "country_code": 214,
                    "country_name": "PARAGUAY"
                },
                {
                    "country_code": 215,
                    "country_name": "GEORGE TOWN, PENANG ISLAND MALAYSIA"
                },
                {
                    "country_code": 216,
                    "country_name": "PERU"
                },
                {
                    "country_code": 217,
                    "country_name": "PITCAIRN ISLAND"
                },
                {
                    "country_code": 218,
                    "country_name": "PORTUGAL"
                },
                {
                    "country_code": 219,
                    "country_name": "PUERTO RICO"
                },
                {
                    "country_code": 220,
                    "country_name": "QATAR"
                },
                {
                    "country_code": 221,
                    "country_name": "REUNION"
                },
                {
                    "country_code": 222,
                    "country_name": "ROMANIA"
                },
                {
                    "country_code": 223,
                    "country_name": "RWANDA"
                },
                {
                    "country_code": 224,
                    "country_name": "SAMOA"
                },
                {
                    "country_code": 226,
                    "country_name": "SAO TOME AND PRINCIPE"
                },
                {
                    "country_code": 227,
                    "country_name": "SENEGAL"
                },
                {
                    "country_code": 228,
                    "country_name": "SERBIA"
                },
                {
                    "country_code": 229,
                    "country_name": "SEYCHELLES"
                },
                {
                    "country_code": 230,
                    "country_name": "SIERRA LEONE"
                },
                {
                    "country_code": 231,
                    "country_name": "WALLIS AND FUTUNA ISLANDS"
                },
                {
                    "country_code": 232,
                    "country_name": "SLOVENIA"
                },
                {
                    "country_code": 233,
                    "country_name": "SOLOMON ISLANDS"
                },
                {
                    "country_code": 234,
                    "country_name": "SOMALIA"
                },
                {
                    "country_code": 235,
                    "country_name": "CURACAO"
                },
                {
                    "country_code": 236,
                    "country_name": "ST KITTS-NEVIS-ANGUILLA"
                },
                {
                    "country_code": 237,
                    "country_name": "ST HELENA & ASCENSION ISLAND"
                },
                {
                    "country_code": 238,
                    "country_name": "ST VINCENT"
                },
                {
                    "country_code": 239,
                    "country_name": "SUDAN"
                },
                {
                    "country_code": 240,
                    "country_name": "SURINAME"
                },
                {
                    "country_code": 241,
                    "country_name": "SVALBARD & JAN MAYEN ISLAND"
                },
                {
                    "country_code": 242,
                    "country_name": "SWAZILAND"
                },
                {
                    "country_code": 243,
                    "country_name": "SYRIA"
                },
                {
                    "country_code": 245,
                    "country_name": "TAJIKISTAN"
                },
                {
                    "country_code": 246,
                    "country_name": "TANZANIA"
                },
                {
                    "country_code": 248,
                    "country_name": "TOGO"
                },
                {
                    "country_code": 249,
                    "country_name": "TOKELAU"
                },
                {
                    "country_code": 250,
                    "country_name": "TONGA"
                },
                {
                    "country_code": 251,
                    "country_name": "TRINIDAD AND TOBAGO"
                },
                {
                    "country_code": 252,
                    "country_name": "TUNISIA"
                },
                {
                    "country_code": 253,
                    "country_name": "TURKMENISTAN"
                },
                {
                    "country_code": 254,
                    "country_name": "TURKS AND CAICOS ISLANDS"
                },
                {
                    "country_code": 255,
                    "country_name": "TUVALU"
                },
                {
                    "country_code": 256,
                    "country_name": "UGANDA"
                },
                {
                    "country_code": 257,
                    "country_name": "UKRAINE"
                },
                {
                    "country_code": 258,
                    "country_name": "UNITED STATES MINOR OUTLAYING ISLANDS"
                },
                {
                    "country_code": 259,
                    "country_name": "ALAND ISLANDS"
                },
                {
                    "country_code": 260,
                    "country_name": "URUGUAY"
                },
                {
                    "country_code": 261,
                    "country_name": "US VIRGIN ISLANDS"
                },
                {
                    "country_code": 262,
                    "country_name": "UZBEKISTAN"
                },
                {
                    "country_code": 263,
                    "country_name": "VANUATU"
                },
                {
                    "country_code": 264,
                    "country_name": "VATICAN CITY STATE(HOLY SEE)"
                },
                {
                    "country_code": 265,
                    "country_name": "VENEZUELA"
                },
                {
                    "country_code": 266,
                    "country_name": "VIETNAM, DEMOCRATIC REP. OF"
                },
                {
                    "country_code": 268,
                    "country_name": "SAN MARINO"
                },
                {
                    "country_code": 269,
                    "country_name": "SOUTH SUDAN"
                },
                {
                    "country_code": 270,
                    "country_name": "TIMOR-LESTE"
                },
                {
                    "country_code": 272,
                    "country_name": "CARRIBIEN NETHARLANDS"
                },
                {
                    "country_code": 273,
                    "country_name": "NONE"
                },
                {
                    "country_code": 274,
                    "country_name": "Mix"
                }
            ],
            "show_participation_visit": [
                {
                    "show_code": 1,
                    "show_name": "Hongkong"
                }
            ],
            "remarks": [
                {
                    "remark_code": 1,
                    "remark_name": "Party KAM Remark"
                },
                {
                    "remark_code": 2,
                    "remark_name": "Party Management Remark"
                },
                {
                    "remark_code": 3,
                    "remark_name": "Party Show Remark"
                },
                {
                    "remark_code": 4,
                    "remark_name": "Contact Person KAM Remark"
                },
                {
                    "remark_code": 5,
                    "remark_name": "Contact Person Management Remark"
                },
                {
                    "remark_code": 6,
                    "remark_name": "Contact Person Show Remark"
                },
                {
                    "remark_code": 7,
                    "remark_name": "Cabin Remark"
                },
                {
                    "remark_code": 8,
                    "remark_name": "Party Account Remark"
                },
                {
                    "remark_code": 9,
                    "remark_name": "Contact Person Account Remark"
                },
                {
                    "remark_code": 10,
                    "remark_name": "Appointment Remark"
                },
                {
                    "remark_code": 11,
                    "remark_name": "Reference Remark"
                },
                {
                    "remark_code": 12,
                    "remark_name": "Address Account Remark"
                },
                {
                    "remark_code": 13,
                    "remark_name": "Address Management Remark"
                },
                {
                    "remark_code": 14,
                    "remark_name": "Grading Missing Entry"
                },
                {
                    "remark_code": 15,
                    "remark_name": "Pol"
                },
                {
                    "remark_code": 16,
                    "remark_name": "Symm"
                },
                {
                    "remark_code": 17,
                    "remark_name": "Fluo"
                },
                {
                    "remark_code": 18,
                    "remark_name": "Consignment Client Permission Remark"
                },
                {
                    "remark_code": 19,
                    "remark_name": "Modify Request - Extra Discount"
                },
                {
                    "remark_code": 20,
                    "remark_name": "Modify Request - Extra Commission"
                },
                {
                    "remark_code": 21,
                    "remark_name": "Modify Request - Premium Commission Write Off\t"
                },
                {
                    "remark_code": 22,
                    "remark_name": "Modify Request - POP Discount"
                },
                {
                    "remark_code": 23,
                    "remark_name": "Modify Request - Additional Discount"
                },
                {
                    "remark_code": 24,
                    "remark_name": "Modify Request - Consignment Charges"
                },
                {
                    "remark_code": 25,
                    "remark_name": "Event Appointment Remark"
                },
                {
                    "remark_code": 26,
                    "remark_name": "Add Note"
                },
                {
                    "remark_code": 27,
                    "remark_name": "Contact Person KYC Remark"
                },
                {
                    "remark_code": 28,
                    "remark_name": "Address KYC Remark"
                },
                {
                    "remark_code": 29,
                    "remark_name": "MFG Remark"
                },
                {
                    "remark_code": 30,
                    "remark_name": "MAT Remark"
                },
                {
                    "remark_code": 31,
                    "remark_name": "Grading Remark"
                },
                {
                    "remark_code": 32,
                    "remark_name": "Modify Request KAM Remark"
                },
                {
                    "remark_code": 33,
                    "remark_name": "Modify Request SA Remark"
                },
                {
                    "remark_code": 34,
                    "remark_name": "KAM Note"
                },
                {
                    "remark_code": 35,
                    "remark_name": "Contact Person Mail Remark"
                },
                {
                    "remark_code": 36,
                    "remark_name": "Contact Person Phone Remark"
                },
                {
                    "remark_code": 37,
                    "remark_name": "Contact person change data remark"
                },
                {
                    "remark_code": 38,
                    "remark_name": "Address change data remark"
                },
                {
                    "remark_code": 39,
                    "remark_name": "Company change data remark"
                },
                {
                    "remark_code": 40,
                    "remark_name": "Party KYC Remark"
                },
                {
                    "remark_code": 41,
                    "remark_name": "Party Mapping Remark"
                },
                {
                    "remark_code": 42,
                    "remark_name": "Purchase Remark"
                }
            ],
            "social_media": [
                {
                    "communication_code": 1,
                    "communication_name": "Facebook"
                },
                {
                    "communication_code": 2,
                    "communication_name": "Skype"
                },
                {
                    "communication_code": 3,
                    "communication_name": "Twitter"
                },
                {
                    "communication_code": 4,
                    "communication_name": "Linkedin"
                },
                {
                    "communication_code": 5,
                    "communication_name": "QQ"
                },
                {
                    "communication_code": 6,
                    "communication_name": "Viber"
                },
                {
                    "communication_code": 7,
                    "communication_name": "Pinterest"
                },
                {
                    "communication_code": 9,
                    "communication_name": "Lime"
                },
                {
                    "communication_code": 10,
                    "communication_name": "WeChat"
                },
                {
                    "communication_code": 11,
                    "communication_name": "Instagram"
                }
            ],
            "documents": [
                {
                    "document_code": 27,
                    "document_name": "Business Registration Copy",
                    "document_type_key": "BUSINESS_REGISTRATION_COPY"
                }
            ],
            "source": [
                {
                    "event_code": 1,
                    "event_name": "Sync System",
                    "event_display_name": "Sync System",
                    "is_active": true
                },
                {
                    "event_code": 2,
                    "event_name": "SRK ONE",
                    "event_display_name": "SRK One",
                    "is_active": true
                },
                {
                    "event_code": 3,
                    "event_name": "SRK Pure",
                    "event_display_name": "SRK Pure",
                    "is_active": true
                },
                {
                    "event_code": 4,
                    "event_name": "Android",
                    "event_display_name": "Android",
                    "is_active": true
                },
                {
                    "event_code": 5,
                    "event_name": "iOS",
                    "event_display_name": "iOS",
                    "is_active": true
                },
                {
                    "event_code": 6,
                    "event_name": "Control Center",
                    "event_display_name": "Control Center",
                    "is_active": true
                },
                {
                    "event_code": 8,
                    "event_name": "SRK One Ipad",
                    "event_display_name": "SRK One iPad",
                    "is_active": true
                },
                {
                    "event_code": 9,
                    "event_name": "SRK One Iphone",
                    "event_display_name": "SRK One iPhone",
                    "is_active": true
                },
                {
                    "event_code": 10,
                    "event_name": "srk_one_android",
                    "event_display_name": "SRK One Andriod",
                    "is_active": true
                },
                {
                    "event_code": 11,
                    "event_name": "Local",
                    "event_display_name": "Local",
                    "is_active": true
                },
                {
                    "event_code": 12,
                    "event_name": "March Hk-2011",
                    "event_display_name": "March Hk-2011",
                    "is_active": true
                },
                {
                    "event_code": 13,
                    "event_name": "Iijs-2011",
                    "event_display_name": "Iijs-2011",
                    "is_active": true
                },
                {
                    "event_code": 14,
                    "event_name": "Iijs-2012",
                    "event_display_name": "Iijs-2012",
                    "is_active": true
                },
                {
                    "event_code": 15,
                    "event_name": "Rapnet",
                    "event_display_name": "Rapnet",
                    "is_active": true
                },
                {
                    "event_code": 16,
                    "event_name": "Idex",
                    "event_display_name": "Idex",
                    "is_active": true
                },
                {
                    "event_code": 17,
                    "event_name": "Reff By Customer",
                    "event_display_name": "Reff By Customer",
                    "is_active": true
                },
                {
                    "event_code": 18,
                    "event_name": "Iijs Signature-2012",
                    "event_display_name": "Iijs Signature-2012",
                    "is_active": true
                },
                {
                    "event_code": 19,
                    "event_name": "Jck-2011",
                    "event_display_name": "Jck-2011",
                    "is_active": true
                },
                {
                    "event_code": 20,
                    "event_name": "Jck-2012",
                    "event_display_name": "Jck-2012",
                    "is_active": true
                },
                {
                    "event_code": 21,
                    "event_name": "Sept Hk-2011",
                    "event_display_name": "Sept Hk-2011",
                    "is_active": true
                },
                {
                    "event_code": 22,
                    "event_name": "Ubm India-2011",
                    "event_display_name": "Ubm India-2011",
                    "is_active": true
                },
                {
                    "event_code": 23,
                    "event_name": "June Hk-2012",
                    "event_display_name": "June Hk-2012",
                    "is_active": true
                },
                {
                    "event_code": 24,
                    "event_name": "Sept Hk-2012",
                    "event_display_name": "Sept Hk-2012",
                    "is_active": true
                },
                {
                    "event_code": 25,
                    "event_name": "London -2012",
                    "event_display_name": "London -2012",
                    "is_active": true
                },
                {
                    "event_code": 26,
                    "event_name": "Sparkle -2013",
                    "event_display_name": "Sparkle -2013",
                    "is_active": true
                },
                {
                    "event_code": 27,
                    "event_name": "Ubm India-2013",
                    "event_display_name": "Ubm India-2013",
                    "is_active": true
                },
                {
                    "event_code": 28,
                    "event_name": "March Hk-2013",
                    "event_display_name": "March Hk-2013",
                    "is_active": true
                },
                {
                    "event_code": 29,
                    "event_name": "Basel-2013",
                    "event_display_name": "Basel-2013",
                    "is_active": true
                },
                {
                    "event_code": 30,
                    "event_name": "Jck-2013",
                    "event_display_name": "Jck-2013",
                    "is_active": true
                },
                {
                    "event_code": 31,
                    "event_name": "June Hk-2013",
                    "event_display_name": "June Hk-2013",
                    "is_active": true
                },
                {
                    "event_code": 32,
                    "event_name": "Iijs-2013",
                    "event_display_name": "Iijs-2013",
                    "is_active": true
                },
                {
                    "event_code": 33,
                    "event_name": "Sept Hk-2013",
                    "event_display_name": "Sept Hk-2013",
                    "is_active": true
                },
                {
                    "event_code": 34,
                    "event_name": "March Hk-2014",
                    "event_display_name": "March Hk-2014",
                    "is_active": true
                },
                {
                    "event_code": 35,
                    "event_name": "Jck-2014",
                    "event_display_name": "Jck-2014",
                    "is_active": true
                },
                {
                    "event_code": 36,
                    "event_name": "June Hk- 2014",
                    "event_display_name": "June Hk- 2014",
                    "is_active": true
                },
                {
                    "event_code": 37,
                    "event_name": "Iijs-2014",
                    "event_display_name": "Iijs-2014",
                    "is_active": true
                },
                {
                    "event_code": 38,
                    "event_name": "Indo Us D.week-2014",
                    "event_display_name": "Indo Us D.week-2014",
                    "is_active": true
                },
                {
                    "event_code": 39,
                    "event_name": "Sept Hk-2014",
                    "event_display_name": "Sept Hk-2014",
                    "is_active": true
                },
                {
                    "event_code": 40,
                    "event_name": "Social Media",
                    "event_display_name": "Social Media",
                    "is_active": true
                },
                {
                    "event_code": 41,
                    "event_name": "Magazine",
                    "event_display_name": "Magazine",
                    "is_active": true
                },
                {
                    "event_code": 42,
                    "event_name": "Jck-2015",
                    "event_display_name": "Jck-2015",
                    "is_active": true
                },
                {
                    "event_code": 43,
                    "event_name": "June Hk-2015",
                    "event_display_name": "June Hk-2015",
                    "is_active": true
                },
                {
                    "event_code": 44,
                    "event_name": "Far East Office",
                    "event_display_name": "Far East Office",
                    "is_active": true
                },
                {
                    "event_code": 45,
                    "event_name": "Self Leads",
                    "event_display_name": "Self Leads",
                    "is_active": true
                },
                {
                    "event_code": 46,
                    "event_name": "March Hk-2015",
                    "event_display_name": "March Hk-2015",
                    "is_active": true
                },
                {
                    "event_code": 47,
                    "event_name": "Sept Hk-2015",
                    "event_display_name": "Sept Hk-2015",
                    "is_active": true
                },
                {
                    "event_code": 48,
                    "event_name": "March Hk 2016",
                    "event_display_name": "March Hk 2016",
                    "is_active": true
                },
                {
                    "event_code": 49,
                    "event_name": "Basel-2016",
                    "event_display_name": "Basel-2016",
                    "is_active": true
                },
                {
                    "event_code": 50,
                    "event_name": "Jck Las Vegas Show 2016",
                    "event_display_name": "Jck Las Vegas Show 2016",
                    "is_active": true
                },
                {
                    "event_code": 51,
                    "event_name": "June Hk-2016",
                    "event_display_name": "June Hk-2016",
                    "is_active": true
                },
                {
                    "event_code": 52,
                    "event_name": "Sept Hk-2016",
                    "event_display_name": "Sept Hk-2016",
                    "is_active": true
                },
                {
                    "event_code": 53,
                    "event_name": "Iijs-2016",
                    "event_display_name": "Iijs-2016",
                    "is_active": true
                },
                {
                    "event_code": 54,
                    "event_name": "Jck Prive 2016 (ny)",
                    "event_display_name": "Jck Prive 2016 (ny)",
                    "is_active": true
                },
                {
                    "event_code": 55,
                    "event_name": "Web Site",
                    "event_display_name": "Web Site",
                    "is_active": true
                },
                {
                    "event_code": 56,
                    "event_name": "November Hk 2016",
                    "event_display_name": "November Hk 2016",
                    "is_active": true
                },
                {
                    "event_code": 57,
                    "event_name": "November Hk-2016",
                    "event_display_name": "November Hk-2016",
                    "is_active": true
                },
                {
                    "event_code": 58,
                    "event_name": "Hongkong Show, March-2017",
                    "event_display_name": "Hongkong Show, March-2017",
                    "is_active": true
                },
                {
                    "event_code": 59,
                    "event_name": "Basel-2017",
                    "event_display_name": "Basel-2017",
                    "is_active": true
                },
                {
                    "event_code": 60,
                    "event_name": "Jck Vegas 2017",
                    "event_display_name": "Jck Vegas 2017",
                    "is_active": true
                },
                {
                    "event_code": 61,
                    "event_name": "Hongkong June Show 2017",
                    "event_display_name": "Hongkong June Show 2017",
                    "is_active": true
                },
                {
                    "event_code": 62,
                    "event_name": "Iijs 2017",
                    "event_display_name": "Iijs 2017",
                    "is_active": true
                },
                {
                    "event_code": 63,
                    "event_name": "Hongkong September Show 2017",
                    "event_display_name": "Hongkong September Show 2017",
                    "is_active": true
                },
                {
                    "event_code": 64,
                    "event_name": "Hongkong November Show 2017",
                    "event_display_name": "Hongkong November Show 2017",
                    "is_active": true
                },
                {
                    "event_code": 65,
                    "event_name": "Belgium Visit 2018",
                    "event_display_name": "Belgium Visit 2018",
                    "is_active": true
                },
                {
                    "event_code": 66,
                    "event_name": "Italy Visit 2018",
                    "event_display_name": "Italy Visit 2018",
                    "is_active": true
                },
                {
                    "event_code": 67,
                    "event_name": "Hongkong Show March - 2018",
                    "event_display_name": "Hongkong Show March - 2018",
                    "is_active": true
                },
                {
                    "event_code": 68,
                    "event_name": "Baselworld - 2018",
                    "event_display_name": "Baselworld - 2018",
                    "is_active": true
                },
                {
                    "event_code": 69,
                    "event_name": "Indonesia Visit 2018",
                    "event_display_name": "Indonesia Visit 2018",
                    "is_active": true
                },
                {
                    "event_code": 70,
                    "event_name": "Diamond Week 2018 @ Bharat Diamond Bourse",
                    "event_display_name": "Diamond Week 2018 @ Bharat Diamond Bourse",
                    "is_active": true
                },
                {
                    "event_code": 71,
                    "event_name": "Jck Las Vegas - 2018",
                    "event_display_name": "Jck Las Vegas - 2018",
                    "is_active": true
                },
                {
                    "event_code": 72,
                    "event_name": "Hong Kong Jewellery & Gem Fair June - 2018",
                    "event_display_name": "Hong Kong Jewellery & Gem Fair June - 2018",
                    "is_active": true
                },
                {
                    "event_code": 73,
                    "event_name": "India International Jewellery Show 2018",
                    "event_display_name": "India International Jewellery Show 2018",
                    "is_active": true
                },
                {
                    "event_code": 74,
                    "event_name": "Hong Kong Jewellery & Gem Fair September - 2018",
                    "event_display_name": "Hong Kong Jewellery & Gem Fair September - 2018",
                    "is_active": true
                },
                {
                    "event_code": 75,
                    "event_name": "Client Visit Los Angeles 2018",
                    "event_display_name": "Client Visit Los Angeles 2018",
                    "is_active": true
                },
                {
                    "event_code": 76,
                    "event_name": "Gems & Jewellery Week 2018",
                    "event_display_name": "Gems & Jewellery Week 2018",
                    "is_active": true
                },
                {
                    "event_code": 77,
                    "event_name": "Israel Visit - Tel Aviv",
                    "event_display_name": "Israel Visit - Tel Aviv",
                    "is_active": true
                },
                {
                    "event_code": 78,
                    "event_name": "Hong Kong Jewelry & Gem Fair – Feb 2019",
                    "event_display_name": "Hong Kong Jewelry & Gem Fair – Feb 2019",
                    "is_active": true
                },
                {
                    "event_code": 79,
                    "event_name": "Australia & New Zealand - Visit",
                    "event_display_name": "Australia & New Zealand - Visit",
                    "is_active": true
                },
                {
                    "event_code": 80,
                    "event_name": "Baselworld - 2019",
                    "event_display_name": "Baselworld - 2019",
                    "is_active": true
                },
                {
                    "event_code": 81,
                    "event_name": "Visit @ London,united Kingdom",
                    "event_display_name": "Visit @ London,united Kingdom",
                    "is_active": true
                },
                {
                    "event_code": 82,
                    "event_name": "Vietnam Visit - Ho Chi Minh City",
                    "event_display_name": "Vietnam Visit - Ho Chi Minh City",
                    "is_active": true
                },
                {
                    "event_code": 83,
                    "event_name": "Cambodia Visit - Phnom Penh",
                    "event_display_name": "Cambodia Visit - Phnom Penh",
                    "is_active": true
                },
                {
                    "event_code": 84,
                    "event_name": "Jck Las Vegas - 2019",
                    "event_display_name": "Jck Las Vegas - 2019",
                    "is_active": true
                },
                {
                    "event_code": 85,
                    "event_name": "Hong Kong Jewellery & Gem Fair - June 2019",
                    "event_display_name": "Hong Kong Jewellery & Gem Fair - June 2019",
                    "is_active": true
                },
                {
                    "event_code": 86,
                    "event_name": "Iijs Premiere Show 2019",
                    "event_display_name": "Iijs Premiere Show 2019",
                    "is_active": true
                },
                {
                    "event_code": 87,
                    "event_name": "Hong Kong Jewellery & Gem Fair - September 2019",
                    "event_display_name": "Hong Kong Jewellery & Gem Fair - September 2019",
                    "is_active": true
                },
                {
                    "event_code": 88,
                    "event_name": "Gjepc Diamond Week",
                    "event_display_name": "Gjepc Diamond Week",
                    "is_active": true
                },
                {
                    "event_code": 89,
                    "event_name": "Dubai Visit 2020",
                    "event_display_name": "Dubai Visit 2020",
                    "is_active": true
                },
                {
                    "event_code": 90,
                    "event_name": "Dof Reference",
                    "event_display_name": "Dof Reference",
                    "is_active": true
                },
                {
                    "event_code": 91,
                    "event_name": "Diamond Week 2018",
                    "event_display_name": "Diamond Week 2018",
                    "is_active": true
                },
                {
                    "event_code": 92,
                    "event_name": "Jck Virtual 2020",
                    "event_display_name": "Jck Virtual 2020",
                    "is_active": true
                },
                {
                    "event_code": 93,
                    "event_name": "SolGoldi",
                    "event_display_name": "SolGoldi",
                    "is_active": true
                },
                {
                    "event_code": 99,
                    "event_name": "Pure OnGo Android",
                    "event_display_name": "Pure OnGo Android",
                    "is_active": true
                },
                {
                    "event_code": 101,
                    "event_name": "Honkong",
                    "event_display_name": "HK",
                    "is_active": true
                },
                {
                    "event_code": 102,
                    "event_name": "Honkong",
                    "event_display_name": "HK",
                    "is_active": true
                },
                {
                    "event_code": 103,
                    "event_name": "Honkong",
                    "event_display_name": "HK",
                    "is_active": true
                },
                {
                    "event_code": 106,
                    "event_name": "Pure Go iPhone",
                    "event_display_name": "Pure Go iPhone",
                    "is_active": true
                },
                {
                    "event_code": 107,
                    "event_name": "Pure Go iPad",
                    "event_display_name": "Pure Go iPad",
                    "is_active": true
                },
                {
                    "event_code": 113,
                    "event_name": "Israel",
                    "event_display_name": "ISL",
                    "is_active": true
                },
                {
                    "event_code": 114,
                    "event_name": "USA JCK 2022",
                    "event_display_name": "JCK",
                    "is_active": true
                },
                {
                    "event_code": 115,
                    "event_name": "Switzerland",
                    "event_display_name": "SWZ",
                    "is_active": true
                },
                {
                    "event_code": 118,
                    "event_name": "JCK 2022",
                    "event_display_name": "JCK 2022",
                    "is_active": true
                },
                {
                    "event_code": 119,
                    "event_name": "USA",
                    "event_display_name": "USA",
                    "is_active": true
                },
                {
                    "event_code": 120,
                    "event_name": "USA",
                    "event_display_name": "USA",
                    "is_active": true
                },
                {
                    "event_code": 121,
                    "event_name": "uk",
                    "event_display_name": "uk",
                    "is_active": true
                },
                {
                    "event_code": 126,
                    "event_name": "Test3",
                    "event_display_name": "Test3",
                    "is_active": true
                },
                {
                    "event_code": 128,
                    "event_name": "Test1",
                    "event_display_name": "Test1",
                    "is_active": true
                },
                {
                    "event_code": 130,
                    "event_name": "Test",
                    "event_display_name": "Test",
                    "is_active": true
                },
                {
                    "event_code": 131,
                    "event_name": "dfgh",
                    "event_display_name": "fgh",
                    "is_active": true
                },
                {
                    "event_code": 132,
                    "event_name": "Hong Kong International Jewelry Show",
                    "event_display_name": "HKTDC",
                    "is_active": true
                }
            ],
            "party_contacts_category": [
                {
                    "category_code": 1,
                    "category_name": "Primary",
                    "category_key": "PRIMARY"
                },
                {
                    "category_code": 2,
                    "category_name": "Secondary",
                    "category_key": "SECONDARY"
                },
                {
                    "category_code": 3,
                    "category_name": "Others",
                    "category_key": "OTHER"
                }
            ],
            "documents_status": [
                {
                    "status_code": 1,
                    "status_name": "Verified",
                    "status_key": "Verified"
                },
                {
                    "status_code": 2,
                    "status_name": "Pending",
                    "status_key": "Pending"
                },
                {
                    "status_code": 3,
                    "status_name": "Rejected",
                    "status_key": "Rejected"
                },
                {
                    "status_code": 4,
                    "status_name": "Deactive",
                    "status_key": "Deactive"
                }
            ],
            "statutory_registration_type": [
                {
                    "statutory_registration_type_code": 1,
                    "statutory_registration_type_name": "Registered",
                    "is_statutory_number_required": true,
                    "statutory_registration_type_key": "REGISTERED"
                },
                {
                    "statutory_registration_type_code": 2,
                    "statutory_registration_type_name": "Unregistered",
                    "is_statutory_number_required": false,
                    "statutory_registration_type_key": "UNREGISTERED"
                },
                {
                    "statutory_registration_type_code": 3,
                    "statutory_registration_type_name": "Registered Exempt",
                    "is_statutory_number_required": false,
                    "statutory_registration_type_key": "CONSUMER"
                },
                {
                    "statutory_registration_type_code": 4,
                    "statutory_registration_type_name": "Composition",
                    "is_statutory_number_required": true,
                    "statutory_registration_type_key": "COMPOSITION"
                },
                {
                    "statutory_registration_type_code": 5,
                    "statutory_registration_type_name": "Exempted",
                    "is_statutory_number_required": false,
                    "statutory_registration_type_key": "EXEMPTED"
                },
                {
                    "statutory_registration_type_code": 7,
                    "statutory_registration_type_name": "Import of service RCM",
                    "is_statutory_number_required": false,
                    "statutory_registration_type_key": "IMPORT_OF_SERVICE_RCM"
                },
                {
                    "statutory_registration_type_code": 8,
                    "statutory_registration_type_name": "Import of service Exempt",
                    "is_statutory_number_required": false,
                    "statutory_registration_type_key": "IMPORT_OF_SERVICE_EXEMPT"
                },
                {
                    "statutory_registration_type_code": 9,
                    "statutory_registration_type_name": "Import of goods",
                    "is_statutory_number_required": false,
                    "statutory_registration_type_key": "IMPORT_OF_SERVICE_GOODS"
                },
                {
                    "statutory_registration_type_code": 10,
                    "statutory_registration_type_name": "NON GST Supply",
                    "is_statutory_number_required": false,
                    "statutory_registration_type_key": "NON_GST_SUPPLY"
                },
                {
                    "statutory_registration_type_code": 12,
                    "statutory_registration_type_name": "Unknown",
                    "is_statutory_number_required": false,
                    "statutory_registration_type_key": "UNKNOWN"
                },
                {
                    "statutory_registration_type_code": 13,
                    "statutory_registration_type_name": "RCM",
                    "is_statutory_number_required": false,
                    "statutory_registration_type_key": "RCM"
                }
            ],
            "parsol_status_of_company": [
                {
                    "status_code": 1,
                    "status_name": "Active",
                    "status_key": "active"
                },
                {
                    "status_code": 2,
                    "status_name": "In-Active",
                    "status_key": "inactive"
                }
            ],
            "source_type_master": [
                {
                    "source_type_code": 1,
                    "source_type_desc": "Contact Person Mail",
                    "source_type_key": "contact_person_mail"
                },
                {
                    "source_type_code": 2,
                    "source_type_desc": "Contact Person Document",
                    "source_type_key": "contact_person_document"
                },
                {
                    "source_type_code": 3,
                    "source_type_desc": "Contact Person Phone",
                    "source_type_key": "contact_person_phone"
                },
                {
                    "source_type_code": 4,
                    "source_type_desc": "Address Document",
                    "source_type_key": "address_document"
                },
                {
                    "source_type_code": 5,
                    "source_type_desc": "Party Reference Document",
                    "source_type_key": "party_reference_document"
                },
                {
                    "source_type_code": 6,
                    "source_type_desc": "Solitaire user Mail",
                    "source_type_key": "solitaire_user_mail"
                },
                {
                    "source_type_code": 7,
                    "source_type_desc": "Solitaire User Phone",
                    "source_type_key": "solitaire_user_phone"
                },
                {
                    "source_type_code": 8,
                    "source_type_desc": "Party Communication",
                    "source_type_key": "party_communication"
                },
                {
                    "source_type_code": 9,
                    "source_type_desc": "Address Mail",
                    "source_type_key": "address_mail"
                },
                {
                    "source_type_code": 10,
                    "source_type_desc": "Address Phone",
                    "source_type_key": "address_phone"
                },
                {
                    "source_type_code": 11,
                    "source_type_desc": "Reference",
                    "source_type_key": "reference"
                },
                {
                    "source_type_code": 12,
                    "source_type_desc": "Address",
                    "source_type_key": "address"
                },
                {
                    "source_type_code": 13,
                    "source_type_desc": "Contact Person",
                    "source_type_key": "contact_person"
                },
                {
                    "source_type_code": 14,
                    "source_type_desc": "Party Remark",
                    "source_type_key": "party_remark"
                },
                {
                    "source_type_code": 15,
                    "source_type_desc": "Contact Person Remark",
                    "source_type_key": "contact_person_remark"
                },
                {
                    "source_type_code": 16,
                    "source_type_desc": "Contact Person Communication",
                    "source_type_key": "contact_person_communication"
                },
                {
                    "source_type_code": 17,
                    "source_type_desc": "Kam Email Address",
                    "source_type_key": "kam_email_Address"
                },
                {
                    "source_type_code": 18,
                    "source_type_desc": "Company Document",
                    "source_type_key": "companyDocument"
                },
                {
                    "source_type_code": 19,
                    "source_type_desc": "Address Remark",
                    "source_type_key": "address_remark"
                },
                {
                    "source_type_code": 20,
                    "source_type_desc": "Accounts Contact Person Mail",
                    "source_type_key": "account_contact_person_mail"
                },
                {
                    "source_type_code": 21,
                    "source_type_desc": "Accounts Contact Person Phone",
                    "source_type_key": "account_contact_person_phone"
                },
                {
                    "source_type_code": 22,
                    "source_type_desc": "Accounts Contact Person Document",
                    "source_type_key": "account_contact_person_document"
                },
                {
                    "source_type_code": 23,
                    "source_type_desc": "Party Tag",
                    "source_type_key": "party_tag"
                },
                {
                    "source_type_code": 24,
                    "source_type_desc": "Contact Person Tag",
                    "source_type_key": "contact_person_tag"
                },
                {
                    "source_type_code": 25,
                    "source_type_desc": "Accounts Address Phone",
                    "source_type_key": "account_address_phone"
                },
                {
                    "source_type_code": 26,
                    "source_type_desc": "Accounts Address Mail",
                    "source_type_key": "account_address_mail"
                },
                {
                    "source_type_code": 27,
                    "source_type_desc": "Accounts Address Address",
                    "source_type_key": "account_vendor_address"
                },
                {
                    "source_type_code": 28,
                    "source_type_desc": "Accounts Vendor Tds Certy",
                    "source_type_key": "account_vendor_tds_certy"
                },
                {
                    "source_type_code": 29,
                    "source_type_desc": "Account Vendor Complience Document",
                    "source_type_key": "account_vendor_complience_document"
                },
                {
                    "source_type_code": 30,
                    "source_type_desc": "Accounts Address Fax",
                    "source_type_key": "account_address_fax"
                },
                {
                    "source_type_code": 32,
                    "source_type_desc": "Organization Address Phone",
                    "source_type_key": "Organization_Address_Phone"
                },
                {
                    "source_type_code": 33,
                    "source_type_desc": "Organization Address Mail",
                    "source_type_key": "Organization_Address_Mail"
                },
                {
                    "source_type_code": 34,
                    "source_type_desc": "Organization Document",
                    "source_type_key": "Organization_Document"
                },
                {
                    "source_type_code": 35,
                    "source_type_desc": "Branch Address Phone",
                    "source_type_key": "Branch_Address_Phone"
                },
                {
                    "source_type_code": 36,
                    "source_type_desc": "Branch Address Mail",
                    "source_type_key": "Branch_Address_Mail"
                },
                {
                    "source_type_code": 37,
                    "source_type_desc": "Branch Document",
                    "source_type_key": "Branch_Document"
                },
                {
                    "source_type_code": 38,
                    "source_type_desc": "Branch Signature",
                    "source_type_key": "Branch_Signature"
                },
                {
                    "source_type_code": 39,
                    "source_type_desc": "Organization Fax",
                    "source_type_key": "Organization_Address_Fax"
                },
                {
                    "source_type_code": 40,
                    "source_type_desc": "Branch Fax",
                    "source_type_key": "Branch_Address_Fax"
                },
                {
                    "source_type_code": 41,
                    "source_type_desc": "Fixed Assets Location Address",
                    "source_type_key": "Fixed_Assets_Location_Address"
                },
                {
                    "source_type_code": 42,
                    "source_type_desc": "Fixed Assets Location Mail",
                    "source_type_key": "Fixed_Assets_Location_Mail"
                },
                {
                    "source_type_code": 43,
                    "source_type_desc": "Fixed Assets Location Phone",
                    "source_type_key": "Fixed_Assets_Location_Phone"
                },
                {
                    "source_type_code": 44,
                    "source_type_desc": "Fixed Assets Location Fax",
                    "source_type_key": "Fixed_Assets_Location_Fax"
                },
                {
                    "source_type_code": 45,
                    "source_type_desc": "Accounts Statutory Numbers",
                    "source_type_key": "Account_Statutory_Numbers"
                },
                {
                    "source_type_code": 46,
                    "source_type_desc": "Accounts Bank Statutory Numbers",
                    "source_type_key": "Bank_Statutory_Numbers"
                },
                {
                    "source_type_code": 47,
                    "source_type_desc": "Party Statutory Numbers",
                    "source_type_key": "Party_Statutory_Numbers"
                },
                {
                    "source_type_code": 48,
                    "source_type_desc": "Accounts Director Document",
                    "source_type_key": "Director_Document"
                },
                {
                    "source_type_code": 49,
                    "source_type_desc": "Accounts Carrier Address Mail",
                    "source_type_key": "Carrier_Address_Mail"
                },
                {
                    "source_type_code": 50,
                    "source_type_desc": "Accounts Carrier Address Phone",
                    "source_type_key": "Carrier_Address_Phone"
                },
                {
                    "source_type_code": 51,
                    "source_type_desc": "Accounts LUT Application",
                    "source_type_key": "LUT_Application"
                },
                {
                    "source_type_code": 52,
                    "source_type_desc": "Accounts LUT Certificate",
                    "source_type_key": "LUT_Certificate"
                },
                {
                    "source_type_code": 53,
                    "source_type_desc": "Accounts Invoice GST",
                    "source_type_key": "Invoice_GST"
                },
                {
                    "source_type_code": 55,
                    "source_type_desc": "Accounts Payment Receipt Income Expense",
                    "source_type_key": "Payment Receipt Income Expense"
                },
                {
                    "source_type_code": 56,
                    "source_type_desc": "Consignment Select Client Popup",
                    "source_type_key": "consignment_select_client_popup"
                },
                {
                    "source_type_code": 57,
                    "source_type_desc": "Accounts Income Expense GST",
                    "source_type_key": "Income_Expense_GST"
                },
                {
                    "source_type_code": 58,
                    "source_type_desc": "Accounts Forward Contract Expense",
                    "source_type_key": "Forward_Contract_Expense"
                },
                {
                    "source_type_code": 59,
                    "source_type_desc": "Accounts Loan Income Expense",
                    "source_type_key": "Loan Income Expense"
                },
                {
                    "source_type_code": 60,
                    "source_type_desc": "Accounts Forward Contract Cancellation Expense",
                    "source_type_key": "Forward Contract Cancellation Expense"
                },
                {
                    "source_type_code": 61,
                    "source_type_desc": "Import Payment Income Expense",
                    "source_type_key": "Import Payment Income Expense"
                },
                {
                    "source_type_code": 62,
                    "source_type_desc": "Adv Import Payment Income Expense",
                    "source_type_key": "Adv Import Payment Income Expense"
                },
                {
                    "source_type_code": 63,
                    "source_type_desc": "Accounts TDS Documents",
                    "source_type_key": "account_tds_documents"
                },
                {
                    "source_type_code": 65,
                    "source_type_desc": "party tds documents",
                    "source_type_key": "party_tds_document"
                },
                {
                    "source_type_code": 66,
                    "source_type_desc": "Solitaire user document",
                    "source_type_key": "Solitaire user document"
                },
                {
                    "source_type_code": 67,
                    "source_type_desc": "Accounts Labour details GST",
                    "source_type_key": "Labour_details_GST"
                },
                {
                    "source_type_code": 68,
                    "source_type_desc": "Contact Person Fax",
                    "source_type_key": "contact_person_fax"
                },
                {
                    "source_type_code": 69,
                    "source_type_desc": "Address Fax",
                    "source_type_key": "address_fax"
                },
                {
                    "source_type_code": 70,
                    "source_type_desc": "handling company address",
                    "source_type_key": "handling_company_address"
                },
                {
                    "source_type_code": 71,
                    "source_type_desc": "KAM",
                    "source_type_key": "kam"
                },
                {
                    "source_type_code": 72,
                    "source_type_desc": "ACCOUNTS JOURNAL_DETAILS GST",
                    "source_type_key": "JOURNAL_DETAILS_GST"
                },
                {
                    "source_type_code": 73,
                    "source_type_desc": "Bank Account",
                    "source_type_key": "BANK_ACCOUNT"
                },
                {
                    "source_type_code": 74,
                    "source_type_desc": "HandlingComp Statutory Numbers",
                    "source_type_key": "HandlingCompany_Statutory_Numbers"
                },
                {
                    "source_type_code": 75,
                    "source_type_desc": "Kam Personal Mail",
                    "source_type_key": "kam_personal_mail"
                },
                {
                    "source_type_code": 76,
                    "source_type_desc": "Address Qbc",
                    "source_type_key": "address_qbc"
                },
                {
                    "source_type_code": 77,
                    "source_type_desc": "Solitaire User Address",
                    "source_type_key": "Solitaire_User_Address"
                },
                {
                    "source_type_code": 78,
                    "source_type_desc": "Party KYC",
                    "source_type_key": "PARTY_KYC"
                },
                {
                    "source_type_code": 79,
                    "source_type_desc": "Contact Person KYC",
                    "source_type_key": "CONTACT_PERSON_KYC"
                },
                {
                    "source_type_code": 80,
                    "source_type_desc": "Address KYC",
                    "source_type_key": "ADDRESS_KYC"
                },
                {
                    "source_type_code": 81,
                    "source_type_desc": "PARTY CDU",
                    "source_type_key": "PARTY_CDU"
                },
                {
                    "source_type_code": 82,
                    "source_type_desc": "CONTACT PERSON CDU",
                    "source_type_key": "CONTACT_PERSON_CDU"
                },
                {
                    "source_type_code": 83,
                    "source_type_desc": "ADDRESS CDU",
                    "source_type_key": "ADDRESS_CDU"
                },
                {
                    "source_type_code": 86,
                    "source_type_desc": "Broker Remark",
                    "source_type_key": "broker_remark"
                },
                {
                    "source_type_code": 87,
                    "source_type_desc": "guarantor Remark",
                    "source_type_key": "guarantor_remark"
                }
            ],
            "company_types": [
                {
                    "company_type_code": 1,
                    "company_type_desc": "Regular",
                    "company_type_key": "REGULAR"
                },
                {
                    "company_type_code": 2,
                    "company_type_desc": "Stock Sharing",
                    "company_type_key": "STOCK_SHARING"
                }
            ],
            "default_kam_bank_code": [
                {
                    "account_type_name": "Diamond Dollar Account",
                    "bank_code": 2037
                },
                {
                    "account_type_name": "Current Account",
                    "bank_code": 1590
                },
                {
                    "account_type_name": "Current Account",
                    "bank_code": 2019
                },
                {
                    "account_type_name": "Diamond Dollar Account",
                    "bank_code": 1591
                },
                {
                    "account_type_name": "Diamond Dollar Account",
                    "bank_code": 2
                },
                {
                    "account_type_name": "Current Account",
                    "bank_code": 1
                }
            ]
        },
        "contact_person": {
            "party_role": [
                {
                    "role_code": 1,
                    "role_name": "Buyer",
                    "role_key": "BUYER",
                    "permission_key": "css_sales_pms_add_new_party_buyer_role_checkbox",
                    "is_ams_active": false
                },
                {
                    "role_code": 2,
                    "role_name": "Party",
                    "role_key": "GUARANTOR",
                    "permission_key": "css_sales_pms_add_new_party_guarantor_role_checkbox",
                    "is_ams_active": false
                },
                {
                    "role_code": 3,
                    "role_name": "Broker",
                    "role_key": "BROKER",
                    "permission_key": "css_sales_pms_add_new_party_broker_role_checkbox",
                    "is_ams_active": false
                },
                {
                    "role_code": 4,
                    "role_name": "Shipping",
                    "role_key": "SHIPPING",
                    "permission_key": "css_sales_pms_add_new_party_shipping_role_checkbox",
                    "is_ams_active": false
                },
                {
                    "role_code": 5,
                    "role_name": "Billing",
                    "role_key": "BILLING",
                    "permission_key": "css_sales_pms_add_new_party_billing_role_checkbox",
                    "is_ams_active": true
                },
                {
                    "role_code": 6,
                    "role_name": "Rough",
                    "role_key": "ROUGH_PURCHASE",
                    "permission_key": "css_sales_pms_add_new_party_rough_purchase_role_checkbox",
                    "is_ams_active": false
                },
                {
                    "role_code": 7,
                    "role_name": "Pick Up",
                    "role_key": "PICK_UP",
                    "permission_key": "css_sales_pms_add_new_party_pickup_role_checkbox",
                    "is_ams_active": false
                },
                {
                    "role_code": 8,
                    "role_name": "Certification Vendor",
                    "role_key": "CERTIFICATION_VENDOR",
                    "is_ams_active": false
                },
                {
                    "role_code": 9,
                    "role_name": "None",
                    "role_key": "NONE",
                    "permission_key": "sales_none_role",
                    "is_ams_active": false
                },
                {
                    "role_code": 10,
                    "role_name": "Purchase",
                    "role_key": "Purchase",
                    "permission_key": "sales_purchase_role",
                    "is_ams_active": false
                },
                {
                    "role_code": 11,
                    "role_name": "Parcel",
                    "role_key": "PARCEL",
                    "permission_key": "css_sales_pms_add_new_party_parcel_role_checkbox",
                    "is_ams_active": false
                }
            ],
            "web_login": [
                {
                    "status_code": 1,
                    "status_name": "Web-Active",
                    "status_key": "WEB_ACTIVE"
                },
                {
                    "status_code": 4,
                    "status_name": "Disable",
                    "status_key": "DISABLE"
                },
                {
                    "status_code": 6,
                    "status_name": "Not Alloted",
                    "status_key": "NOT_ALLOTED"
                }
            ],
            "designation": [
                {
                    "designation_code": 1,
                    "designation_name": "Manager"
                },
                {
                    "designation_code": 2,
                    "designation_name": "Employee"
                },
                {
                    "designation_code": 3,
                    "designation_name": "Proprietor"
                },
                {
                    "designation_code": 4,
                    "designation_name": "Partner"
                },
                {
                    "designation_code": 5,
                    "designation_name": "Director"
                },
                {
                    "designation_code": 6,
                    "designation_name": "Chairman"
                },
                {
                    "designation_code": 7,
                    "designation_name": "CEO"
                },
                {
                    "designation_code": 8,
                    "designation_name": "CFO"
                },
                {
                    "designation_code": 9,
                    "designation_name": "Other Designation"
                }
            ],
            "permission": [
                {
                    "role_code": 1,
                    "role_name": "Admin"
                },
                {
                    "role_code": 2,
                    "role_name": "User"
                }
            ],
            "prefered_mode": [
                {
                    "contact_mode_code": 1,
                    "contact_mode_name": "Email",
                    "is_pms": true,
                    "is_communication_system": true,
                    "contact_mode_icon": "https://srk.one/pure/images/Mail.png"
                },
                {
                    "contact_mode_code": 2,
                    "contact_mode_name": "Phone",
                    "is_pms": true,
                    "is_communication_system": true,
                    "contact_mode_icon": "https://srk.one/pure/images/Call.png"
                },
                {
                    "contact_mode_code": 3,
                    "contact_mode_name": "Skype",
                    "is_pms": true,
                    "is_communication_system": true,
                    "contact_mode_icon": "https://srk.one/pure/images/Skypee.png"
                },
                {
                    "contact_mode_code": 4,
                    "contact_mode_name": "Meeting",
                    "is_pms": true,
                    "is_communication_system": true,
                    "contact_mode_icon": "https://srk.one/pure/images/Meeting.png"
                },
                {
                    "contact_mode_code": 5,
                    "contact_mode_name": "WhatsApp",
                    "is_pms": true,
                    "is_communication_system": true,
                    "contact_mode_icon": "https://srk.one/pure/images/Whatsapp.png"
                },
                {
                    "contact_mode_code": 6,
                    "contact_mode_name": "Presentation",
                    "is_pms": true,
                    "is_communication_system": true,
                    "contact_mode_icon": "https://srk.one/pure/images/Presentation.png"
                },
                {
                    "contact_mode_code": 7,
                    "contact_mode_name": "BuyerCabin",
                    "is_pms": true,
                    "is_communication_system": true,
                    "contact_mode_icon": "https://srk.one/pure/images/BuyerCabin.png"
                },
                {
                    "contact_mode_code": 8,
                    "contact_mode_name": "Exhibitions",
                    "is_pms": true,
                    "is_communication_system": true,
                    "contact_mode_icon": "https://srk.one/pure/images/Exhibitions.png"
                },
                {
                    "contact_mode_code": 9,
                    "contact_mode_name": "OtherSource",
                    "is_pms": true,
                    "is_communication_system": true,
                    "contact_mode_icon": "https://srk.one/pure/images/Others.png"
                }
            ],
            "prefered_language": [
                {
                    "language_code": 1,
                    "language_name": "English"
                },
                {
                    "language_code": 2,
                    "language_name": "Hindi"
                },
                {
                    "language_code": 3,
                    "language_name": "Gujarati"
                },
                {
                    "language_code": 4,
                    "language_name": "Chinese"
                }
            ],
            "prefered_day": [
                {
                    "day_code": 1,
                    "day_name": "Sunday"
                },
                {
                    "day_code": 2,
                    "day_name": "Monday"
                },
                {
                    "day_code": 3,
                    "day_name": "Tuesday"
                },
                {
                    "day_code": 4,
                    "day_name": "Wednesday"
                },
                {
                    "day_code": 5,
                    "day_name": "Thursday"
                },
                {
                    "day_code": 6,
                    "day_name": "Friday"
                },
                {
                    "day_code": 7,
                    "day_name": "Saturday"
                }
            ],
            "remarks": [
                {
                    "remark_code": 1,
                    "remark_name": "Party KAM Remark"
                },
                {
                    "remark_code": 2,
                    "remark_name": "Party Management Remark"
                },
                {
                    "remark_code": 3,
                    "remark_name": "Party Show Remark"
                },
                {
                    "remark_code": 4,
                    "remark_name": "Contact Person KAM Remark"
                },
                {
                    "remark_code": 5,
                    "remark_name": "Contact Person Management Remark"
                },
                {
                    "remark_code": 6,
                    "remark_name": "Contact Person Show Remark"
                },
                {
                    "remark_code": 7,
                    "remark_name": "Cabin Remark"
                },
                {
                    "remark_code": 8,
                    "remark_name": "Party Account Remark"
                },
                {
                    "remark_code": 9,
                    "remark_name": "Contact Person Account Remark"
                },
                {
                    "remark_code": 10,
                    "remark_name": "Appointment Remark"
                },
                {
                    "remark_code": 11,
                    "remark_name": "Reference Remark"
                },
                {
                    "remark_code": 12,
                    "remark_name": "Address Account Remark"
                },
                {
                    "remark_code": 13,
                    "remark_name": "Address Management Remark"
                },
                {
                    "remark_code": 14,
                    "remark_name": "Grading Missing Entry"
                },
                {
                    "remark_code": 15,
                    "remark_name": "Pol"
                },
                {
                    "remark_code": 16,
                    "remark_name": "Symm"
                },
                {
                    "remark_code": 17,
                    "remark_name": "Fluo"
                },
                {
                    "remark_code": 18,
                    "remark_name": "Consignment Client Permission Remark"
                },
                {
                    "remark_code": 19,
                    "remark_name": "Modify Request - Extra Discount"
                },
                {
                    "remark_code": 20,
                    "remark_name": "Modify Request - Extra Commission"
                },
                {
                    "remark_code": 21,
                    "remark_name": "Modify Request - Premium Commission Write Off\t"
                },
                {
                    "remark_code": 22,
                    "remark_name": "Modify Request - POP Discount"
                },
                {
                    "remark_code": 23,
                    "remark_name": "Modify Request - Additional Discount"
                },
                {
                    "remark_code": 24,
                    "remark_name": "Modify Request - Consignment Charges"
                },
                {
                    "remark_code": 25,
                    "remark_name": "Event Appointment Remark"
                },
                {
                    "remark_code": 26,
                    "remark_name": "Add Note"
                },
                {
                    "remark_code": 27,
                    "remark_name": "Contact Person KYC Remark"
                },
                {
                    "remark_code": 28,
                    "remark_name": "Address KYC Remark"
                },
                {
                    "remark_code": 29,
                    "remark_name": "MFG Remark"
                },
                {
                    "remark_code": 30,
                    "remark_name": "MAT Remark"
                },
                {
                    "remark_code": 31,
                    "remark_name": "Grading Remark"
                },
                {
                    "remark_code": 32,
                    "remark_name": "Modify Request KAM Remark"
                },
                {
                    "remark_code": 33,
                    "remark_name": "Modify Request SA Remark"
                },
                {
                    "remark_code": 34,
                    "remark_name": "KAM Note"
                },
                {
                    "remark_code": 35,
                    "remark_name": "Contact Person Mail Remark"
                },
                {
                    "remark_code": 36,
                    "remark_name": "Contact Person Phone Remark"
                },
                {
                    "remark_code": 37,
                    "remark_name": "Contact person change data remark"
                },
                {
                    "remark_code": 38,
                    "remark_name": "Address change data remark"
                },
                {
                    "remark_code": 39,
                    "remark_name": "Company change data remark"
                },
                {
                    "remark_code": 40,
                    "remark_name": "Party KYC Remark"
                },
                {
                    "remark_code": 41,
                    "remark_name": "Party Mapping Remark"
                },
                {
                    "remark_code": 42,
                    "remark_name": "Purchase Remark"
                }
            ],
            "documents": [
                {
                    "document_code": 1,
                    "document_name": "Pancard",
                    "document_type_key": "PANCARD"
                },
                {
                    "document_code": 29,
                    "document_name": "Driving Licence",
                    "document_type_key": "DRIVING_LICENCE"
                },
                {
                    "document_code": 3,
                    "document_name": "Passport",
                    "document_type_key": "PASSPORT"
                },
                {
                    "document_code": 2,
                    "document_name": "Adhar Card",
                    "document_type_key": "ADHAR_CARD"
                },
                {
                    "document_code": 30,
                    "document_name": "Voter ID",
                    "document_type_key": "VOTER_ID"
                },
                {
                    "document_code": 36,
                    "document_name": "Client Card",
                    "document_type_key": "CLIENT_CARD"
                }
            ],
            "documents_status": [
                {
                    "status_code": 1,
                    "status_name": "Verified",
                    "status_key": "Verified"
                },
                {
                    "status_code": 2,
                    "status_name": "Pending",
                    "status_key": "Pending"
                },
                {
                    "status_code": 3,
                    "status_name": "Rejected",
                    "status_key": "Rejected"
                },
                {
                    "status_code": 4,
                    "status_name": "Deactive",
                    "status_key": "Deactive"
                }
            ]
        }
    }
}

var b={
    "company_details":[
        {
            "company_name": "Trade PVT",
            "account_status_key": 4,
            "handling_company_code": 3,
            "grade_code": 5,
            "business_type_code": 14,
            "group_code": 8,
            "trade_code": 51,
            "office_country_code": 23,
            "communication_code": 11,
            "event_code": 31,
            "category_code": 3,
            "documents_status": {
                "status_code": 4
            },
            "source_type_code": 32,
            "bank_code": 1590,
            "contact_person" : {
                "role_code": 11,
                "web_login": {
                    "status_code": 4
                },
                "designation_code": 9,
                "permission": {
                    "role_code": 2
                },
                "contact_person_documents":{
                    "submited_documents":[29,30,36],
                    "doc_status": 4
                }
                    
            }
        },
        {
            "company_name": "Marco Down",
            "account_status_key": 2,
            "handling_company_code": 1,
            "grade_code": 4,
            "business_type_code": 13,
            "group_code": 6,
            "trade_code": 34,
            "office_country_code": 22,
            "communication_code": 7,
            "event_code": 20,
            "category_code": 2,
            "documents_status": {
                "status_code": 2
            },
            "source_type_code": 24,
            "bank_code": 1591,
            "contact_person" : {
                "role_code": 10,
                "web_login": {
                    "status_code": 1
                },
                "designation_code": 7,
                "permission": {
                    "role_code": 1
                },
                "contact_person_documents":{
                    "submited_documents":[1,30],
                    "doc_status": 1
                }
                    
            }
        },
        {
            "company_name": "France D'code",
            "account_status_key": 3,
            "handling_company_code": 2,
            "grade_code": 3,
            "business_type_code": 12,
            "group_code": 5,
            "trade_code": 33,
            "office_country_code":20 ,
            "communication_code": 5,
            "event_code": 18,
            "category_code": 1,
            "documents_status": {
                "status_code": 2
            },
            "source_type_code": 22,
            "bank_code": 2,
            "contact_person" : {
                "role_code": 8,
                "web_login": {
                    "status_code": 6
                },
                "designation_code": 6,
                "permission": {
                    "role_code": 2
                },
                "contact_person_documents":{
                    "submited_documents":[30,36,1],
                    "doc_status": 2
                }
                    
            }
        },
        {
            "company_name": "Untitle Mark",
            "account_status_key": 2,
            "handling_company_code": 1,
            "grade_code": 2,
            "business_type_code": 10,
            "group_code": 4,
            "trade_code": 31,
            "office_country_code": 18,
            "communication_code": 4,
            "event_code": 16,
            "category_code": 2,
            "documents_status": {
                "status_code": 1
            },
            "source_type_code": 20,
            "bank_code": 2019,
            "contact_person" : {
                "role_code": 5,
                "web_login": {
                    "status_code": 1
                },
                "designation_code": 3,
                "permission": {
                    "role_code": 1
                },
                "contact_person_documents":{
                    "submited_documents":[1,3,36],
                    "doc_status": 2
                }
                    
            }
        },
        {
            "company_name": "D'Rose Mark",
            "account_status_key": 1,
            "handling_company_code": 2,
            "grade_code": 1,
            "business_type_code": 8,
            "group_code": 2,
            "trade_code": 30,
            "office_country_code": 16,
            "communication_code": 2,
            "event_code": 12,
            "category_code": 1,
            "documents_status": {
                "status_code": 2
            },
            "source_type_code": 18,
            "bank_code": 2037,
            "contact_person" : {
                "role_code": 2,
                "web_login": {
                    "status_code": 4
                },
                "designation_code": 2,
                "permission": {
                    "role_code": 2
                },
                "contact_person_documents":{
                    "submited_documents":[30],
                    "doc_status": 3
                }
                    
            }
        }
    ]
}

let Documents=[]


b.company_details.map(statusKey=>{
    console.log("Company_Name: "+ statusKey.company_name)
    // Company_Name.push(statusKey.company_name)
    // console.log(statusKey.account_status_key)
    a.data.company_info.account_status_of_company.map(statusCode=>{
        // console.log(statusCode.status_code)

        if(statusKey.account_status_key==statusCode.status_code){
            console.log("Status_Name : " + statusCode.status_name +" for " +statusKey.company_name)
        }

    })

    a.data.company_info.handling_company.map(handleCompany=>{
        if(statusKey.handling_company_code==handleCompany.company_code){
            console.log("Handling_Company_Name: "+handleCompany.company_name)
        }

    })
    a.data.company_info.company_grade.map(grade=>{
        if(grade.grade_code==statusKey.grade_code){
            console.log("Grade_Name :" + grade.grade_name)
        }
    })

    a.data.company_info.business_type.map(business=>{
        if(business.business_type_code==statusKey.business_type_code){
            console.log("Business_Type_Name: "+business.business_type_name)
        }
    })
    
    a.data.company_info.company_group.map(group=>{
        if(group.group_code==statusKey.group_code){
            console.log("Group_Name: "+group.group_name)
        }
    })

    a.data.company_info.member_of_trade.map(member=>{
        if(member.trade_code==statusKey.trade_code){
            console.log("Trade_Name: "+member.trade_name)
        }
    })

    a.data.company_info.offices_countries.map(office=>{
        if(office.country_code==statusKey.office_country_code){
            console.log("Country_Name: "+office.country_name)
        }
    })
    a.data.company_info.social_media.map(social=>{
        if(social.communication_code==statusKey.communication_code){
            console.log("Communication_Name: "+social.communication_name)
        }
    })
    a.data.company_info.source.map(source=>{
        if(source.event_code==statusKey.event_code){
            console.log("Event_Name: "+source.event_name)
        }
    })
    a.data.company_info.party_contacts_category.map(categories=>{
        if(categories.category_code==statusKey.category_code){
            console.log("Categories_Name: "+categories.category_name)
        }
    })
    a.data.company_info.documents_status.map(document=>{
        if(document.status_code==statusKey.documents_status.status_code){
            console.log("Status_Name: "+document.status_name)
        }
    })

    a.data.company_info.source_type_master.map(sourceType=>{
        if(sourceType.source_type_code==statusKey.source_type_code){
            console.log("Source_type_desc: "+sourceType.source_type_desc)
        }
    })
a.data.company_info.default_kam_bank_code.map(bank=>{
    if(bank.bank_code==statusKey.bank_code){
        console.log("Account_type_Name: "+bank.account_type_name)
    }
})

a.data.contact_person.party_role.map(party=>{
    if(party.role_code==statusKey.contact_person.role_code){
        console.log("Role_Name: "+party.role_name)
    }
})
a.data.contact_person.web_login.map(web=>{
    if(web.status_code==statusKey.contact_person.web_login.status_code){
        console.log("Status_Name: "+web.status_name)
    }
})
a.data.contact_person.designation.map(destination=>{
    if(destination.designation_code==statusKey.contact_person.designation_code){
        console.log("Destination_Name: "+destination.designation_name)
    }
})

a.data.contact_person.permission.map(permission=>{
    if(permission.role_code==statusKey.contact_person.permission.role_code){
        console.log("Permission_Role_Name: "+permission.role_name)
    }
})

a.data.contact_person.documents.map(documents=>{
    statusKey.contact_person.contact_person_documents.submited_documents.map(d_code=>{
        if(d_code==documents.document_code){
            // console.log(documents.document_name)
            Documents.push(documents.document_name)
        }
    })
})

console.log("Document_Name: "+Documents)

a.data.contact_person.documents_status.map(d_status=>{
    if(d_status.status_code==statusKey.contact_person.contact_person_documents.doc_status){
        console.log("Document_Status: "+d_status.status_name)
    }
    
})

    console.log("--------------------------------------------")
    
})

